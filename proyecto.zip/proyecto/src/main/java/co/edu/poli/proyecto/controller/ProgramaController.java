package co.edu.poli.proyecto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.edu.poli.proyecto.model.Programa;
import co.edu.poli.proyecto.repository.ProgramaRepository;

@RestController 
@RequestMapping("/proyecto")
public class ProgramaController {
	
	@Autowired
	private ProgramaRepository programaRepository;
	

	@GetMapping("/consultar/programas")
	public List<Programa> getAllBooks() {
	return programaRepository.findAll();
	}
	
	@GetMapping("/consultar/programa/{id}")
	public Programa getBookById(@PathVariable Integer id) { 
	Programa programa =  programaRepository.findById(id).get();
	return programa;
	}
	
	//Guarda una programa
	@PostMapping("/guardar/programa")
	public Programa savePrograma (@RequestBody Programa programa) {
	programaRepository.save(programa);	
	return programa;
		}
		
	//Guarda una lista de  programas
	@PostMapping("/guardar/programas")
	public String savePrograma (@RequestBody List<Programa> programaList) {
	programaRepository.saveAll(programaList);	
	return "done";
	}
	
	@PutMapping("/actualizar/programa/{id}")
	public Programa updatePrograma(@PathVariable Integer id, @RequestBody Programa programaNew) {
	Programa programadb = programaRepository.findById(id).get();

		programadb.setIdPrograma(programaNew.getIdPrograma());
		programadb.setNombrePrograma(programaNew.getNombrePrograma());
		programadb.setEscuela(programaNew.getEscuela());
		programaRepository.save(programadb);
		return programadb;
	}
	
	@DeleteMapping("/borrar/programas/{id}")
	public Programa deletePrograma(@PathVariable Integer id) {
		Programa programab = programaRepository.findById(id).get();
		programaRepository.delete(programab);
		return programab;
	}
}
