package co.edu.poli.proyecto.model;

import java.util.Date;
import java.util.Set;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "estudiante")

public class Estudiante {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	//private int idEstudiante;
	private String numeroDocumento;
	private String nombres;
	private String apellidos;
	private String tipoTrabajo;
	private String tituloTrabajo;
	private Date fechaSustentacion;

	/*
	@ManyToMany
	@JoinTable(name = "Estudiante_Programa",
			joinColumns = { @JoinColumn(name = "Estudiante_idEstudiante", unique=true) }, 
			inverseJoinColumns = {@JoinColumn(name = "Programa_idPrograma", unique=true)})
	private Set<Programa> dataSetProgramas;
	*/
	
	
	@ManyToOne
    @JoinColumn(name = "programa")
    private Programa programa;
	
	public Estudiante() {
		super();
	}

	public Estudiante(String numeroDocumento, String nombres, String apellidos, String tipoTrabajo,
			String tituloTrabajo, Date fechaSustentacion, Programa programa) {
		super();
		this.numeroDocumento = numeroDocumento;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.tipoTrabajo = tipoTrabajo;
		this.tituloTrabajo = tituloTrabajo;
		this.fechaSustentacion = fechaSustentacion;
		this.programa = programa;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getTipoTrabajo() {
		return tipoTrabajo;
	}

	public void setTipoTrabajo(String tipoTrabajo) {
		this.tipoTrabajo = tipoTrabajo;
	}

	public String getTituloTrabajo() {
		return tituloTrabajo;
	}

	public void setTituloTrabajo(String tituloTrabajo) {
		this.tituloTrabajo = tituloTrabajo;
	}

	public Date getFechaSustentacion() {
		return fechaSustentacion;
	}

	public void setFechaSustentacion(Date fechaSustentacion) {
		this.fechaSustentacion = fechaSustentacion;
	}

	public Programa getPrograma() {
		return programa;
	}

	public void setPrograma(Programa programa) {
		this.programa = programa;
	}
	
	
}
