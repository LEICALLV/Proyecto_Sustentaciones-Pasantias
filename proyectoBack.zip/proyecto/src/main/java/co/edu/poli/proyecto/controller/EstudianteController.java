package co.edu.poli.proyecto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.edu.poli.proyecto.model.Estudiante;
import co.edu.poli.proyecto.repository.EstudianteRepository;

@CrossOrigin(origins = "http://127.0.0.1:4200")
@RestController
@RequestMapping("/api/v1/")
public class EstudianteController {

	@Autowired
	private EstudianteRepository estudianteRepository;
	

	@GetMapping("/consultar/estudiantes")
	public List<Estudiante> getAllEstudiantes() {
	return estudianteRepository.findAll();
	}
	
	@GetMapping("/consultar/estudiante/{id}")
	public Estudiante getBookById(@PathVariable String id) { 
	Estudiante estudiante =  estudianteRepository.findById(id).get();
	return estudiante;
	}
	
	//Guarda una estudiante
	@PostMapping("/guardar/estudiantes")
	public Estudiante saveEstudiante (@RequestBody Estudiante estudiante) {
	estudianteRepository.save(estudiante);	
	return estudiante;
		}
		
	//Guarda una lista de  estudiantes
	@PostMapping("/guardar/estudiantess")
	public String saveEstudiante (@RequestBody List<Estudiante> estudianteList) {
	estudianteRepository.saveAll(estudianteList);	
	return "done";
	}
	
	@PutMapping("/actualizar/estudiantes/{id}")
	public Estudiante updateEstudiante(@PathVariable String id, @RequestBody Estudiante estudianteNew) {
	Estudiante estudiantedb = estudianteRepository.findById(id).get();

		
		estudiantedb.setNumeroDocumento(estudianteNew.getNumeroDocumento());
		estudiantedb.setNombres(estudianteNew.getNombres());
		estudiantedb.setApellidos(estudianteNew.getApellidos());
		estudiantedb.setTipoTrabajo(estudianteNew.getTipoTrabajo());
		estudiantedb.setTituloTrabajo(estudianteNew.getTituloTrabajo());
		estudiantedb.setFechaSustentacion(estudianteNew.getFechaSustentacion());
		
		estudianteRepository.save(estudiantedb);
		return estudiantedb;
	}
	
	@DeleteMapping("/borrar/estudiantes/{id}")
	public Estudiante deleteEstudiante(@PathVariable String id) {
	Estudiante estudiante = estudianteRepository.findById(id).get();
	estudianteRepository.delete(estudiante);
	return estudiante;
	}
}
