package co.edu.poli.proyecto.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "programa")
public class Programa {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// @JsonIgnore
	private int idPrograma;
	private String nombrePrograma;
	private String escuela;

	@OneToMany(mappedBy = "programa")
	@JsonIgnore
	private Set<Estudiante> estudiante;

	/*
	 * @ManyToOne
	 * 
	 * @JoinColumn(name = "idEstudiantes", unique=true)
	 * 
	 * @JsonIgnore
	 * 
	 * @ManyToMany
	 * 
	 * @JoinTable(name = "Estudiante_Programa", joinColumns = { @JoinColumn(name =
	 * "Estudiante_idEstudiante", unique=true) }, inverseJoinColumns =
	 * {@JoinColumn(name = "Programa_idPrograma", unique=true)}) private
	 * Set<Programa> dataSetProgramas;
	 */
	// muchas escuelas
	// @ManyToOne
	// @JoinColumn(name = "escuela_idEscuela")
	// @JsonIgnore
	// private Escuela escuela;
	// private Set<Escuela> dataSetEscuelas;

	// @ManyToMany
	// @JoinColumn(name = "estudiante_idEstudiante")
	// @JsonIgnore
	// private Estudiante estudiante;
	// private Set<Estudiante> dataSetEstudiantes;

	public Programa() {

	}

	public Programa(int idPrograma, String nombrePrograma, String escuela, Set<Estudiante> estudiante) {
		super();
		this.idPrograma = idPrograma;
		this.nombrePrograma = nombrePrograma;
		this.escuela = escuela;
		this.estudiante = estudiante;
	}

	public int getIdPrograma() {
		return idPrograma;
	}

	public void setIdPrograma(int idPrograma) {
		this.idPrograma = idPrograma;
	}

	public String getNombrePrograma() {
		return nombrePrograma;
	}

	public void setNombrePrograma(String nombrePrograma) {
		this.nombrePrograma = nombrePrograma;
	}

	public String getEscuela() {
		return escuela;
	}

	public void setEscuela(String escuela) {
		this.escuela = escuela;
	}

	public Set<Estudiante> getEstudiante() {
		return estudiante;
	}

	public void setEstudiante(Set<Estudiante> estudiante) {
		this.estudiante = estudiante;
	}

	
}
