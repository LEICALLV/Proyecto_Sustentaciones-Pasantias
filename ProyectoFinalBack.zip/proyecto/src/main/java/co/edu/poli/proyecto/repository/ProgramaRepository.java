package co.edu.poli.proyecto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.poli.proyecto.model.Programa;

public interface ProgramaRepository extends JpaRepository<Programa, Integer>{

}
