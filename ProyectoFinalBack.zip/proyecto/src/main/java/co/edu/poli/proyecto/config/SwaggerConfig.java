package co.edu.poli.proyecto.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Bean
	public Docket escuelaApi() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				//.apis(RequestHandlerSelectors.basePackage("co.edu.poli.mongodb.controller")) //Specific package
				.apis(RequestHandlerSelectors.basePackage("co.edu.poli")) //All project
				//.paths(PathSelectors.regex("/api/v1.*")) //filter RequestMapping with regular expression
				.paths(PathSelectors.any())
				.build()
				.apiInfo(mysqlEscuelaApiInfo())
				.tags(new Tag("Proyecto", "*** Proyecto***"));
				//.tags(new Tag("Class: EscuelaController", "*** EscuelaController ***"));
	}

	private ApiInfo mysqlEscuelaApiInfo() {
		return new ApiInfoBuilder()
				.title("Proyecto")
				.description("Proyecto REST API Spring Boot and MySQL")
				.contact(new Contact("Carlos Forero&Leidy Callejas", "", "cforero@poligran.edu.co&lcallejas@poligran.edu.co"))
				.version("0.0.1")
				.build();
	}
	
	public Docket programaApi() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				//.apis(RequestHandlerSelectors.basePackage("co.edu.poli.mongodb.controller")) //Specific package
				.apis(RequestHandlerSelectors.basePackage("co.edu.poli")) //All project
				//.paths(PathSelectors.regex("/api/v1.*")) //filter RequestMapping with regular expression
				.paths(PathSelectors.any())
				.build()
				.apiInfo(mysqlProgramaApiInfo())
				.tags(new Tag("Class: ProgramaController", "*** ProgramaController ***"));
	}

	private ApiInfo mysqlProgramaApiInfo() {
		return new ApiInfoBuilder()
				.title("Programa")
				.description("Programas REST API Spring Boot and MySQL")
				.contact(new Contact("Carlos Forero", "", "cforero@poligran.edu.co"))
				.version("0.0.1")
				.build();
	}
	
	public Docket estudianteApi() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				//.apis(RequestHandlerSelectors.basePackage("co.edu.poli.mongodb.controller")) //Specific package
				.apis(RequestHandlerSelectors.basePackage("co.edu.poli")) //All project
				//.paths(PathSelectors.regex("/api/v1.*")) //filter RequestMapping with regular expression
				.paths(PathSelectors.any())
				.build()
				.apiInfo(mysqlEstudianteApiInfo())
				.tags(new Tag("Class: EstudianteController", "*** EstudianteController ***"));
	}

	private ApiInfo mysqlEstudianteApiInfo() {
		return new ApiInfoBuilder()
				.title("Estudiante")
				.description("Estudiantes REST API Spring Boot and MySQL")
				.contact(new Contact("Carlos Forero", "", "cforero@poligran.edu.co"))
				.version("0.0.1")
				.build();
	}
}
	