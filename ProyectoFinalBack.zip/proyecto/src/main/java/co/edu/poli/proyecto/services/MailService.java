package co.edu.poli.proyecto.services;

import co.edu.poli.proyecto.model.Mail;

public interface MailService {

	public void sendEmail (Mail mail);
	
}
