import { Programa } from './../model/programa';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Estudiante } from './../model/estudiante';

const postUrl = 'http://localhost:8080/proyecto/guardar/programas';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  programa:Programa[];
  estudiante: Estudiante[];
  
  constructor(private http: HttpClient) { }
 
  getUrl = 'http://localhost:8080/proyecto/consultar/programas';
  getIdUrl = 'http://localhost:8080/proyecto/consultar/programa';
  postUrl = 'http://localhost:8080/proyecto/guardar/programa';
  putUrl = 'http://localhost:8080/proyecto/actualizar/programa';
  deleteUrl = 'http://localhost:8080/proyecto/borrar/programa';
  
  /***************************************************************************/
  getEstUrl = 'http://localhost:8080/proyecto/consultar/estudiantes';
  getEstIdUrl = 'http://localhost:8080/proyecto/consultar/estudiante';
  postEstUrl = 'http://localhost:8080/proyecto/guardar/estudiante';
  deleteEstUrl = 'http://localhost:8080/proyecto/borrar/estudiantes';
  putUrlEst = 'http://localhost:8080/proyecto/actualizar/estudiante';

  getProgramas(){
    return this.http.get<Programa []>(this.getUrl);
  }
  getProgramaId(idPrograma:number){
    return this.http.get<Programa>(this.getIdUrl+"/"+idPrograma);
  }
  updatePrograma(programa:Programa){
    return this.http.put<Programa>(this.putUrl+"/"+programa.idPrograma,programa)
  }
  createPrograma(programa:Programa){
    return this.http.post<Programa>(this.postUrl,programa);
  }

  deletePrograma(programa:Programa){
    return this.http.delete<Programa>(this.deleteUrl+"/"+programa.idPrograma)
  }

  /***********************************************/
  //METODOS ESTUDIANTES
  getEstudiantes(){
    return this.http.get<Estudiante []>(this.getEstUrl);
  }
  createEstudiante(estudiante:Estudiante){
    return this.http.post<Estudiante>(this.postEstUrl,estudiante);
  }

  deleteEstudiante(estudiante:Estudiante){
    return this.http.delete<Estudiante>(this.deleteEstUrl+"/"+estudiante.numeroDocumento)
  }
  getEstudianteId(numeroDocumento:string){
    return this.http.get<Estudiante>(this.getEstIdUrl+"/"+numeroDocumento);
  }
  updateEstudiante(estudiante:Estudiante){
    return this.http.put<Estudiante>(this.putUrlEst+"/"+estudiante.numeroDocumento,estudiante)
  }

}
/*
getProgramaId(idPrograma:number){
  return this.http.get<Programa>(this.getIdUrl+"/"+idPrograma);
}
updatePrograma(programa:Programa){
  return this.http.put<Programa>(this.putUrl+"/"+programa.idPrograma,programa)
}
*/