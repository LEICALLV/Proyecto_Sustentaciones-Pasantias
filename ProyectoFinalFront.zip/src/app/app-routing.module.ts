import { EditProgramaComponent } from './components/edit-programa/edit-programa.component';
import { EditEstudianteComponent} from './components/edit-estudiante/edit-estudiante.component'
import { ListProgramaComponent } from './components/list-programa/list-programa.component';
import { AddProgramaComponent } from './components/add-programa/add-programa.component';
import { AddEstudianteComponent } from './components/add-estudiante/add-estudiante.component';
import { ListEstudianteComponent } from './components/list-estudiante/list-estudiante.component';
import { ListProyectosComponent } from './components/list-proyectos/list-proyectos.component';


import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path:'add', component:AddProgramaComponent},
  {path:'addEst', component:AddEstudianteComponent},
  {path:'list', component:ListProgramaComponent},
  {path:'listest', component:ListEstudianteComponent},
  {path:'edit', component:EditProgramaComponent},
  {path:'listpro', component:ListProyectosComponent},
  {path:'editest', component:EditEstudianteComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
