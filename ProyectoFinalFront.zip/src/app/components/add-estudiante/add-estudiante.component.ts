import { Component, OnInit } from '@angular/core';
import { Estudiante } from './../../model/estudiante';
import { Router } from '@angular/router';
import { ServiceService} from '../../services/service.service'


@Component({
  selector: 'app-add-estudiante',
  templateUrl: './add-estudiante.component.html',
  styleUrls: ['./add-estudiante.component.css']
})
export class AddEstudianteComponent implements OnInit {

  currentEstudiante = null;
  estudiante = new Estudiante();
  submitted = false;
  msgError = '';

  constructor(private router:Router, private service:ServiceService) { }

  ngOnInit() {
  }

  Guardar(estudiante:Estudiante){
    this.service.createEstudiante(estudiante)
    .subscribe(data=>{
      alert("Se agrego con Exito...!!!");
      this.router.navigate(["listest"]);
    })
  }
}
