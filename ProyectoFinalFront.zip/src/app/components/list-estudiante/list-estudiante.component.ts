import { Programa } from './../../model/programa';
import { Estudiante } from './../../model/estudiante';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService} from '../../services/service.service'

@Component({
  selector: 'app-list-estudiante',
  templateUrl: './list-estudiante.component.html',
  styleUrls: ['./list-estudiante.component.css']
})

export class ListEstudianteComponent implements OnInit {

  estudiantes: Estudiante[];
  programas: Programa[];

  constructor(private service:ServiceService, private router:Router) { }

  Nuevo(){
    this.router.navigate(["addEst"]);
  }

  ngOnInit() {
    this.service.getEstudiantes()
    .subscribe(data=>{
    this.estudiantes=data;
     console.log(data);
    /*
     let es = [{
      numeroDocumento: "123",
      nombres: "Elsa",
      apellidos: "Pito",
      tipoTrabajo: "Pasantias",
      tituloTrabajo: "Prueba",
      fechaSustentacion: new Date(12),
      programa: [{
        idPrograma: 1,
        nombrePrograma: "Ingenieria de Sistemas",
        escuela: "Ingenieria"
    }]
    },
    {
      numeroDocumento: "123",
      nombres: "Elsa",
      apellidos: "Pito",
      tipoTrabajo: "Pasantias",
      tituloTrabajo: "Prueba",
      fechaSustentacion: new Date(12),
      programa: [{
          idPrograma: 1,
          nombrePrograma: "Ingenieria de Sistemas",
          escuela: "Ingenieria"
      }]
    }
  ]*/
    })
  }

  Editar(estudiante:Estudiante):void{
    localStorage.setItem("numeroDocumento",estudiante.numeroDocumento.toString())
    this.router.navigate(["editest"])
  }

  Delete(estudiante:Estudiante){
    this.service.deleteEstudiante(estudiante)
    .subscribe(data=>{
      this.estudiantes=this.estudiantes.filter(p=>p!==estudiante);
      alert("Estudiante eliminado...");
    })
  }

  
  
}


/*
ngOnInit() {
    this.service.getProgramas()
    .subscribe(data=>{
      this.programas=data;
    })
  }

*/