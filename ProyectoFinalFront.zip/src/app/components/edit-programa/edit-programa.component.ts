import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService} from '../../services/service.service'
import { Programa } from './../../model/programa';

@Component({
  selector: 'app-edit-programa',
  templateUrl: './edit-programa.component.html',
  styleUrls: ['./edit-programa.component.css']
})
export class EditProgramaComponent implements OnInit {
  currentPrograma = null;
  programa:Programa = new Programa();
  submitted = false;
  msgError = '';  

  constructor(private service:ServiceService, private router:Router) { }

  ngOnInit(){
    this.Editar();
  }

  Editar(){
    let id = localStorage.getItem("idPrograma");
    this.service.getProgramaId(+id)
    .subscribe(data=>{
      this.programa=data;
      console.log(this.programa)
    })
  }

  Actualizar(programa:Programa){
    this.service.updatePrograma(programa)
    .subscribe(data=>{
      this.programa=data;
      alert("Se Actualizo con exito...!!!");
      this.router.navigate(["list"])
    })
  }

  newPrograma() {
    this.submitted = false;
    this.programa.nombrePrograma= null;
    this.programa.escuela = null;
  }

}
