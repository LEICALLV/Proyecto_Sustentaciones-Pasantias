import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Programa } from 'src/app/model/programa';
import { ServiceService} from '../../services/service.service';

@Component({
  selector: 'app-add-programa',
  templateUrl: './add-programa.component.html',
  styleUrls: ['./add-programa.component.css']
})
export class AddProgramaComponent implements OnInit {
  
  currentPrograma = null;
  programa = new Programa();
  submitted = false;
  msgError = '';

  constructor(private router:Router, private service:ServiceService) { }

  ngOnInit() {
  }

  Guardar(programa:Programa){
    this.service.createPrograma(programa)
    .subscribe(data=>{
      alert("Se agrego con Exito...!!!");
      this.router.navigate(["list"]);
    })
  }

  /*Nuevo(){
    this.router.navigate(["add"]);
  }*/ /*
  savePrograma(): void {
    const data = {
      nombrePrograma: this.programa.nombrePrograma,
      escuela: this.programa.escuela
    };

    this.service.createPrograma(data)
      .subscribe(
        data => {
          this.submitted=true;
          console.log(data);
        },
        error => {
          this.msgError  = error.message +' \n '+ error.error.message;
          console.log(error);
        });
  } */

  newPrograma() {
    this.submitted = false;
    this.programa.nombrePrograma= null;
    this.programa.escuela = null;
  }

}