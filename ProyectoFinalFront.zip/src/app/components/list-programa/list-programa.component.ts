import { Programa } from './../../model/programa';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ServiceService} from '../../services/service.service'

@Component({
  selector: 'app-list-programa',
  templateUrl: './list-programa.component.html',
  styleUrls: ['./list-programa.component.css']
})
export class ListProgramaComponent implements OnInit {

  programas:Programa[];
  constructor(private service:ServiceService, private router:Router) { }

  Nuevo(){
    this.router.navigate(["add"]);
  }

  ngOnInit() {
    this.service.getProgramas()
    .subscribe(data=>{
      this.programas=data;
    })
  }

  Editar(programa:Programa):void{
    localStorage.setItem("idPrograma",programa.idPrograma.toString())
    this.router.navigate(["edit"])
  }

  Delete(programa:Programa){
    this.service.deletePrograma(programa)
    .subscribe(data=>{
      this.programas=this.programas.filter(p=>p!==programa);
      alert("Programa eliminado...");
    })
  }
}
