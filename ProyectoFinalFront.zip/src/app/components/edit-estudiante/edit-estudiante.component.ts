import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService} from '../../services/service.service'
import { Estudiante } from './../../model/estudiante';

@Component({
  selector: 'app-edit-estudiante',
  templateUrl: './edit-estudiante.component.html',
  styleUrls: ['./edit-estudiante.component.css']
})
export class EditEstudianteComponent implements OnInit {
  currentEstudiante = null;
  estudiante:Estudiante = new Estudiante();
  submitted = false;
  msgError = '';  

  constructor(private service:ServiceService, private router:Router) { }

  ngOnInit(){
    this.Editar();
  }

  Editar(){
    let numeroDocumento = localStorage.getItem("numeroDocumento");
    this.service.getEstudianteId(numeroDocumento)
    .subscribe(data=>{
      this.estudiante=data;
      console.log(this.estudiante)
    })
  }

  Actualizar(estudiante:Estudiante){
    this.service.updateEstudiante(estudiante)
    .subscribe(data=>{
      this.estudiante=data;
      alert("Se Actualizo con exito...!!!");
      this.router.navigate(["listest"])
    })
  }

  newEstudiante() {
    this.submitted = false;
    this.estudiante.numeroDocumento= null;
  }
}
