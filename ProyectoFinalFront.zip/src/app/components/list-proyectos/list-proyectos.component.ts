import { Estudiante } from './../../model/estudiante';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService} from '../../services/service.service'


@Component({
  selector: 'app-list-proyectos',
  templateUrl: './list-proyectos.component.html',
  styleUrls: ['./list-proyectos.component.css']
})
export class ListProyectosComponent implements OnInit {

  estudiantes: Estudiante[];
  constructor(private service:ServiceService, private router:Router) { }


  ngOnInit() {
    this.service.getEstudiantes()
    .subscribe(data=>{
      this.estudiantes=data;
     console.log(data);
    })
  }
}
