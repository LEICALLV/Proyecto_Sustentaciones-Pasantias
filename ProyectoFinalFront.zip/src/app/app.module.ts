import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddProgramaComponent } from './components/add-programa/add-programa.component';
import { ListProgramaComponent } from './components/list-programa/list-programa.component';
import { FormsModule} from '@angular/forms'
import { ServiceService } from '../app/services/service.service'
import { HttpClientModule} from '@angular/common/http';
import { AddEstudianteComponent } from './components/add-estudiante/add-estudiante.component';
import { ListEstudianteComponent } from './components/list-estudiante/list-estudiante.component';
import { EditProgramaComponent } from './components/edit-programa/edit-programa.component';
import { ListProyectosComponent } from './components/list-proyectos/list-proyectos.component';
import { EditEstudianteComponent } from './components/edit-estudiante/edit-estudiante.component'


@NgModule({
  declarations: [
    AppComponent,
    AddProgramaComponent,
    ListProgramaComponent,
    AddEstudianteComponent,
    ListEstudianteComponent,
    ListProyectosComponent,
    EditProgramaComponent,
    EditEstudianteComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [ServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
