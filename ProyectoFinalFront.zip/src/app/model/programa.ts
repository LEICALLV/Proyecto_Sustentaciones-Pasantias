export class Programa {
    idPrograma: number;
    nombrePrograma: string;
    escuela: string;

    constructor(){}
}


