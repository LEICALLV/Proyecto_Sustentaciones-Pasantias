import { Programa } from "./programa";

export class Estudiante {
    numeroDocumento : string
    nombres : string
    apellidos : string
    tipoTrabajo : string
    tituloTrabajo : string
    dataSetPrograma : Programa []
    fechaSustentacion : Date
}

