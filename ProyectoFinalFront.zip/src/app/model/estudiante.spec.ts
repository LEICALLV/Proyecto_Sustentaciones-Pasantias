import { Estudiante } from './estudiante';

describe('Estudiante', () => {
  it('should create an instance', () => {
    expect(new Estudiante()).toBeTruthy();
  });
});