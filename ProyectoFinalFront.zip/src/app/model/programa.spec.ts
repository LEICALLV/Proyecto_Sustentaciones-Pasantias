import { Programa } from './programa';

describe('Programa', () => {
  it('should create an instance', () => {
    expect(new Programa()).toBeTruthy();
  });
});
